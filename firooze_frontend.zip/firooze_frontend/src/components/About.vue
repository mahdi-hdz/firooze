<template>
  <center class="pt-10 text-secondary"><h1> About Page </h1></center>
</template>

<script>
export default {

}
</script>

<style>

</style>